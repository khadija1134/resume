const scriptURL = 'https://script.google.com/macros/s/AKfycbxZVXsXBrGL3wSjeP7KCumvsQ9NLKmOgXt0TaGyvtc0OTx-5iwwzy28rdx0J7TUyDN7/exec'

const form = document.forms['Payment-form']

form.addEventListener('submit', e => {
  e.preventDefault()
  fetch(scriptURL, { method: 'POST', body: new FormData(form)})
  // .then(response => alert("Thank you! your form is submitted successfully." ))
  .then(() => { window.location.replace('pages/verify.html'); })
  .catch(error => console.error('Error!', error.message))
})